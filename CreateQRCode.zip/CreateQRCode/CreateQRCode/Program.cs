﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZXing.Common;
using ZXing.QrCode;
using ZXing;
using System.Drawing;

namespace CreateQRCode
{
    internal class Program
    {
        static void Main(string[] args)
        {
          
            Random random = new Random();
            string[] letters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            string firstLetter = letters[random.Next(letters.Length)];
            string secondLetter = letters[random.Next(letters.Length)];

         
            string randomDigits = string.Empty;
            for (int i = 0; i < 6; i++)
            {
                randomDigits += random.Next(0, 10).ToString();
            }

            string qrString = firstLetter + secondLetter + randomDigits;

        
            QRCodeWriter qrEncode = new QRCodeWriter();
            Dictionary<EncodeHintType, object> hints = new Dictionary<EncodeHintType, object>();
            hints.Add(EncodeHintType.CHARACTER_SET, "utf-8");

       
            int qrSize = 4; 
            BitMatrix qrMatrix = qrEncode.encode(qrString, BarcodeFormat.QR_CODE, qrSize, qrSize, hints);

        
            BarcodeWriter qrWrite = new BarcodeWriter();
            Bitmap qrImage = qrWrite.Write(qrMatrix);

         
            qrImage.Save($"{qrString}.bmp", System.Drawing.Imaging.ImageFormat.Bmp);

      
            BarcodeReader qrDecode = new BarcodeReader();
            Result text = qrDecode.Decode((Bitmap)Bitmap.FromFile($"{qrString}.bmp"));

         
            Console.WriteLine("QR-код содержит: {0}", text.Text);
            Console.ReadKey();
        }
    }
}
